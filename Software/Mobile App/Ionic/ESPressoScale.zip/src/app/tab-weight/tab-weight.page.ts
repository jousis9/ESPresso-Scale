import { Component, OnInit, NgZone } from '@angular/core';



import { BLE } from '@ionic-native/ble/ngx';
import { BleService } from '../services/ble.service';

@Component({
    selector: 'app-tab-weight',
    templateUrl: './tab-weight.page.html',
    styleUrls: ['./tab-weight.page.scss'],
})
export class TabWeightPage implements OnInit {

    public devices: any = [];
    public error: any;
    public devicefound: boolean = false;

    public weight: string = "";

    public isConnected: boolean = false;
    public weightNotifications: boolean = false;

    public scaleInUpgradeMode: boolean = false;

    public ipAddress: string = "";

    constructor(public ble: BLE,
        public zone: NgZone,
        private bleService: BleService) {

        this.connect2BLE();

    }

    ngOnInit() {
    }




    public connect2BLE() {
        // this.bleService.doConnect(this.bleService.scale_uuid, this.onConnection, this.onConnectionError);
        this.bleService.startScan();
        // this.startNotification();
        this.zone.run(() => {
            this.bleService.isConnected.subscribe((value) => {
                this.isConnected = value;
            });

            this.bleService.weight.subscribe((value) => {
                this.weight = value;
            });
            this.bleService.scaleOperationMode.subscribe((value) => {
                console.log("new value !");
                if (value == "1") {
                    this.scaleInUpgradeMode = true;
                    //get IP
                    this.bleService.readWriteOption("wifiIP", "get").then((value) => {
                        this.ipAddress = value;
                    })
                } else {
                    this.scaleInUpgradeMode = false;
                }
            })
        })
    }

    public startNotification() {
        console.log("starting notification subscription");
        this.zone.run(() => {
            this.weightNotifications = true;
        });
    }

    reboot() {
        this.weight = "";
        this.isConnected = false;
        this.scaleInUpgradeMode = false;
        this.rwOption("reboot", "1", null);
    }
    tare() {
        // this.weight = "";
        // this.isConnected = false;
        // this.scaleInUpgradeMode = false;
        this.rwOption("tare", "1", null);
    }

    public rwOption(optionName: string, optionValue: string, localVar: any) {
        this.bleService.readWriteOption(optionName, optionValue)
            .then(response => {
                localVar = response;
                console.log(" response for " + optionName + " = " + response);
            });
    }





}
