import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-about',
  templateUrl: './tab-about.page.html',
  styleUrls: ['./tab-about.page.scss'],
})
export class TabAboutPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
