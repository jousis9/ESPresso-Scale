import { Platform } from '@ionic/angular';

import { Injectable, NgZone } from '@angular/core';
import { BLE } from '@ionic-native/ble/ngx';
import { Observable, of, Subscriber, Subject } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class BleService {

    public scale_name: string = "OSES";
    public scale_service_uuid: string = "b75d181d-e85e-11e8-9f32-f2801f1b9fd1";
    public scale_char_weight_uuid: string = "b75d2a9d-e85e-11e8-9f32-f2801f1b9fd1"; //Notify
    public scale_char_settings_uuid: string = "b75d2a9e-e85e-11e8-9f32-f2801f1b9fd3"; //Read/Write


    public scaleDeviceId: string = "";
    public deviceFound: string = "";


    peripheral = "";

    public weight: Subject<string> = new Subject<string>();
    public isConnected: Subject<boolean> = new Subject<boolean>();
    public scaleOperationMode: Subject<string> = new Subject<string>();



    constructor(private ble: BLE,
        private zone: NgZone,
        private platform: Platform) {
    }


    public CancelScan(): void {
        this.ble.stopScan().then(() => { }, () => { });
    }

    public startScan = function () {
        this.isConnected.next(false);
        this.ble.stopScan().then(() => {
            console.log('Scanning for Bluetooth LE Devices');
            this.ble.startScan([]).subscribe(
                device => this.onDeviceDiscovered(device),
                error => this.scanError(error)
            );
        },
            () => {
                console.log('Error stopping scan');
            });
    }


    public readWriteOption(optionName: string, optionValue: string): Promise<any> {
        console.log("reading options");
        if (!this.platform.is("cordova")) {
            console.log("cordova not available...sorry");
            return new Promise((resolve, reject) => {
                resolve("");
            })
        }
        return new Promise((resolve, reject) => {
            this.ble.write(this.scaleDeviceId, this.scale_service_uuid, this.scale_char_settings_uuid, this.stringToBytes(optionName + "=" + optionValue))
                .then(wresponse => {
                    //don't care
                    this.ble.read(this.scaleDeviceId, this.scale_service_uuid, this.scale_char_settings_uuid)
                        .then(rresponse => {
                            console.log("final response " + this.bytesToString(rresponse));
                            resolve(this.bytesToString(rresponse));
                        }).catch(error => {
                            console.log("ble read error " + error);
                            reject("ERROR");
                        })
                }).catch(error => {
                    console.log(error);
                    reject("ERROR");
                })
        })
    }

    scanSuccess = function (device) {
        console.log(JSON.stringify(device));
    }

    scanError = function (error) {
        console.log('Error ' + error);
    }



    onDeviceDiscovered = function (device) {
        if (device.name == this.scale_name) {
            if (device.rssi > -60) {
                console.log("found scale...connecting...");
                this.deviceFound = true;
                this.scaleDeviceId = device.id;
                this.connectToDevice(device);
            }
        }
    }

    bytesToString(buffer: any): string {
        return String.fromCharCode.apply(null, new Uint8Array(buffer));
    }

    stringToBytes(input: string): any {
        var array = new Uint8Array(input.length);
        for (var i = 0, l = input.length; i < l; i++) {
            array[i] = input.charCodeAt(i);
        }
        return array.buffer;
    }


    writeSuccess(response) {

    }


    connectToDevice = function (device: any): void {
        this.ble.stopScan().then(() => {
            this.ble.autoConnect(device.id, peripheral => {
                this.onConnected(peripheral);
            },
                error => {
                    console.log("Disconnection");
                    this.zone.run(() => {
                        this.isConnected.next(false);
                    })
                });

            // this.ble.connect(device.id).subscribe(
            //     peripheral => this.onConnected(peripheral),
            //     peripheral => this.onDeviceDisconnected(peripheral)
            // );
        },
            () => {
                console.log('Error stopping scan');
            });
    }


    onConnected(peripheral) {
        this.peripheral = peripheral;
        console.log("our peripheral ");
        console.log(JSON.stringify(peripheral));

        this.zone.run(() => {
            this.isConnected.next(true);
        })

        this.readWriteOption("upgradeMode", "get").then(response => {
            console.log("new scale operation mode " + response);
            this.zone.run(() => {
                this.scaleOperationMode.next(response);
            })
        })


        this.ble.startNotification(this.scaleDeviceId, this.scale_service_uuid, this.scale_char_weight_uuid).subscribe(
            buffer => {
                var data = new Uint8Array(buffer);
                let weightstr: string = String.fromCharCode.apply(null, new Uint8Array(buffer));
                // console.log(weightstr);
                this.zone.run(() => {
                    this.weight.next(weightstr);
                })
            }
        );
        console.log("device ready");
    }


    onDeviceDisconnected(peripheral) {
        this.zone.run(() => {
            this.isConnected.next(false);
        })
        console.log('disconnected');
    }
}

