import { BleService } from './../services/ble.service';
import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';

@Component({
    selector: 'app-setting-modal',
    templateUrl: './setting-modal.page.html',
    styleUrls: ['./setting-modal.page.scss'],
})
export class SettingModalPage implements OnInit {

    setting: any = {};

    constructor(private navParams: NavParams,
        private modalController: ModalController,
        private bleService: BleService) { }

    ngOnInit() {
        this.setting = this.navParams.get('setting');
        console.log(this.setting.name);
    }

    closeModal() {
        this.modalController.dismiss();
    }


    public rwOption(optionName: string, optionValue: string, setting: any) {
        console.log("should call " + optionName + " with value " + optionValue);
        this.bleService.readWriteOption(optionName, optionValue)
            .then(response => {
                // localVar = response;
                console.log("our local var is " + JSON.stringify(setting));
                console.log(" response for " + optionName + " = " + response);
                if (response == "ERROR") {
                    alert("Could not change value");
                    setting.value = "";
                } else if (response == "OK") {
                    //OK reply only if we try to set a new value and everything went fine
                    this.bleService.readWriteOption(optionName, "get").then(response => {
                        setting.value = response;
                    });
                } else {
                    setting.value = response;
                }

            });
    }

}
