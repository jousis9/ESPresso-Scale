import { BleService } from './../services/ble.service';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { SettingModalPage } from '../setting-modal/setting-modal.page';

@Component({
    selector: 'app-tab-settings',
    templateUrl: './tab-settings.page.html',
    styleUrls: ['./tab-settings.page.scss'],
})
export class TabSettingsPage implements OnInit {

    public settings: any = [
        // { name: "TARE", command: "tare", type: "command", read: false, write: true, value: "1", info: "really ?" }, // tare does not belong in settings, but if you wish, enable it
        {
            name: "Reboot", command: "reboot", type: "command", read: false, write: true, value: "1",
            info: "Immediately reboots scale. BLE will disconnect."
        },
        {
            name: "Upgrade", command: "otaUpgrade", type: "command", read: false, write: true, value: "1",
            info: "Reboots scale in upgrade mode.<br>If wifi connection is not possible, it will reboot again automatically.<br><br>\
                BLE will disconnect briefly but will reconnect again.<br>\
                Immediately after the connection, you can read the assigned IP address." },

        {
            name: "Deep Sleep", command: "deepSleep", type: "command", read: false, write: true, value: "1",
            info: "Immediately puts scale to sleep. This is essentialy its power off mode. BLE will disconnect."
        },
        {
            name: "Calibration", command: "calibrate", type: "number", units: "", read: true, write: true, value: "",
            info: "Calibrate your scale using a known weight.<br><br>\
                Please insert weight in grams with . (dot) as a decimal point.<br><br>\
                Remove any weight from your scale, set a number and press Calibrate. After that, place the weight and wait.<br>\
                Scale will be unresponsive for few seconds (depends on your firmware)."
        },
        {
            name: "Calibration Factor", command: "calFactor", type: "number", units: "", read: true, write: true, value: "",
            info: "Don't mess with it. Only for testing/debugging.<br><br>\
                value here is the actual calibration factor *100"
        },
        {
            name: "Decimal Digits", command: "decimalDigits", type: "values", units: "", read: true, write: true, value: "",
            acceptableValues: [{ name: "0 (ex. 100g)", value: "0" }, { name: "1 (ex. 100.1g)", value: "1" }, { name: "2 (ex. 100.13g)", value: "2" }],
            info: "Decimal digits after the final measurement. Will only affect the weight you will see on the display.<br>\
                Will not affect in any way the resolution and accuracy of the internal functions of the scale."
        },
        {
            name: "Fake Stability Range", command: "fakeRange", type: "number", units: "centigram", read: true, write: true, value: "",
            info: "Do not show changes less than +/- fakeStabilityRange.<br>\
                It will make the scale seem stable around any measured weight. It will not affect any actual measurement. It will not tare.<br>\
                If you don't like watching the measured weight jump constantly around, enable this option.<br><br>\
                On the firmware level, all calculations are done using the real numbers and when the measured weight\
                jumps outside the stable region screen will update immediately."
        },
        {
            name: "LED - Button Press", command: "slBtnPress", type: "values", units: "", read: true, write: true, value: "",
            acceptableValues: [{ name: "Enabled", value: "1" }, { name: "Disabled", value: "0" }],
            info: "Uses the status led for optical feedback when you press buttons.<br>\
                Although led uses low power, it will drain your battery faster."
        },
        {
            name: "LED - Increased Accuracy", command: "slMaxVIN", type: "values", units: "", read: true, write: true, value: "",
            acceptableValues: [{ name: "Enabled", value: "1" }, { name: "Disabled", value: "0" }],
            info: "Keep the status led on when scale operates in increased accuracy mode.<br>\
                Although led uses low power, it will drain your battery faster."
        },
        {
            name: "Operation Mode", command: "scaleMode", type: "values", units: "", read: true, write: true, value: "",
            acceptableValues: [{ name: "Normal Mode", value: "0" }, { name: "Auto Tare", value: "1" }],
            info: "The only thing that makes this scale \"Espresso\".<br><br>\
                For now, our only special mode is auto tare. More will come soon."
        },
        {
            name: "Samples per Read", command: "readSamples", type: "number", units: "", read: true, write: true, value: "",
            info: "How many samples will be averaged for each read of our weight. Set any value from 1 to 255.<br><br>\
                This number will dramatically affect your read speed. If you set it to 5 and your speed is low, you will only get 2 updates per second.<br>\
                But those readings will be very very stable."
        },
        {
            name: "Smoothing", command: "smoothing", type: "values", units: "", read: true, write: true, value: "",
            acceptableValues: [{ name: "Disabled", value: "0" }, { name: "Enabled", value: "1" }],
            info: "Enables or disables smoothing & filtering. If you disable it, Sensitivity setting plays no role.<br><br>\
                One approach to stable readings with reasonable response is to increase samples per read and disable smoothing.<br><br>"
        },
        {
            name: "Sensitivity", command: "sensitivity", type: "number", units: "", read: true, write: true, value: "",
            info: "Set an integer value from 0 (disabled) to 255(max). Depending on your firmware settings, minor changes will not affect anything.<br><br>\
                It is better to select between 0,1,64,128,255.<br><br>\
                0 disables filtering completely (try for slow speed) and 255 maximises it (don't try for slow speed)."
        },
        {
            name: "Speed", command: "adcSpeed", type: "values", units: "SPS", read: true, write: true, value: "",
            acceptableValues: [{ name: "Slow (10SPS)", value: "10" }, { name: "Fast (80SPS)", value: "80" }],
            info: "Scale is capable of reading the weight 10 or 80 times per second.<br>\
                Faster read speed makes the scale super responsive but very unstable unless you select proper values in sensitivity and samples per read."
        },
        {
            name: "Stable Weight Range", command: "stableWeightDiff", type: "number", units: "centigram", read: true, write: true, value: "",
            info: "Scale will consider its load \"stable\" when the output value fluctuates between +/- the selected range.<br>\
                Be careful because if you choose small value and your scale is not so stable (ex with 80SPS w/o filtering) calibration,auto-tare and other functions will not work properly.<br>\
                If you insert 5 centigrams, which is 0.05g, scale will consider the load stable if within +/- 0.05g for some samples (depends on your firmware)<br><br>\
                ex (with 5): 0.00 -> 0.02 (stable) -> -0.04 (stable) -> 0.02 (stable) -> 0.09 (increasing)"
        },
        {
            name: "Timeout - Deep Sleep", command: "deepSleepTimeout", type: "number", units: "10*s", read: true, write: true, value: "",
            info: "During deep sleep, scale shuts down all functions and only responds to button/touch presses.<br>\
                This is essentialy its power off mode.<br>\
                BLE is deactivated<br><br>\
                You must insert a value in 10*s , for example, if you set 5, scale will deep sleep in 50 seconds."
        },
        {
            name: "Timeout - Light Sleep", command: "lightSleepTimeout", type: "number", units: "10*s", read: true, write: true, value: "",
            info: "During light sleep, all functions are halted and display is dimmed.<br>\
                However scale is ready to return to normal within ms.<br>\
                BLE is deactivated<br><br>\
                You must insert a value in 10*s , for example, if you set 5, scale will light sleep in 50 seconds."
        },
        {
            name: "Timeout - Snooze", command: "snoozeTimeout", type: "number", units: "10*s", read: true, write: true, value: "",
            info: "While snoozing, weight refresh is minimized (4/second), display is dimmed.<br>\
            It will return to normal state if you touch any button or if you place any weight.<br>\
            BLE stays active.<br><br>\
            You must insert a value in 10*s , for example, if you set 5, scale will snooze in 50 seconds."
        },
        {
            name: "WiFi IP Address", command: "wifiIP", type: "string", units: "", read: true, write: false, value: "",
            info: "IP address assigned to the scale by your router (only when in upgrade mode)."
        },
        {
            name: "Wifi Name", command: "wifiSSID", type: "string", units: "", read: true, write: true, value: "",
            info: "When scale enters firmware upgrade mode, it will try to connect to this SSID.<br><br>\
                Put a valid SSID here or you will not be able to do OTA Upgrade."
        },
        {
            name: "Wifi Password", command: "wifiPassword", type: "string", units: "", read: true, write: true, value: "",
            info: "The password for your WiFi network that you set on WiFi SSID setting.<br><br>\
                Used only if you want OTA Upgrade."
        },
        {
            name: "Zero Range", command: "zeroRange", type: "number", units: "centigram", read: true, write: true, value: "",
            info: "Scale will show zero (0.00) if weight measured is within +/- zero range grams.<br>\
                It will make the scale seem stable around zero. It will not affect any actual measurement. It will not tare.<br>\
                If you don't like watching the measured weight jump constantly between 0.00, -0.01, 0.01, enable this option.<br>\
                As an example, if you insert 5 centigrams, which is 0.05g, scale will show 0.00 until it goes above 0.05 or below -0.05.<br><br>\
                If the measured weight is 0.01 you will see: 0.00, -0.02 (see: 0.00) , 0.04 (see: 0.00), 0.07 (see: 0.07)"
        },
        {
            name: "Zero Tracking", command: "zeroTracking", type: "number", units: "centigram", read: true, write: true, value: "",
            info: "Scale will auto tare itself if near 0 and if the variation between samples is as low as your setting.<br>\
                If you insert 5 centigrams, which is 0.05g, scale will continiously auto tare until measured weight goes above 0.05g between two measurements.<br><br>\
                ex (with 5): 0.00 -> 0.02 -> TARE -> 0.00 -> 0.01 -> TARE -> 0.00 -> 1.2 -> 1.5 -> 1.9 -> ..."
        },




    ]


    constructor(public bleService: BleService, private modalController: ModalController) { }

    ngOnInit() {
    }

    async openSetting(settingobj: any) {
        const modal = await this.modalController.create({
            component: SettingModalPage,
            componentProps: {
                setting: settingobj
            }
        });
        modal.present();
    }

    public rwOption(optionName: string, optionValue: string, setting: any) {
        console.log("should call " + optionName + " with value " + optionValue);
        if (optionValue != "get" && setting.acceptableValues) {
            //check if this option has acceptable values and if it matches
            let foundit: boolean = false;
            for (let i = 0; i < setting.acceptableValues.length; i++) {
                if (setting.acceptableValues[i] == optionValue) {
                    foundit = true;
                    break;
                }
            }
            if (!foundit) {
                console.log("value not accepted");
                alert("Please select one of the following values : " + setting.acceptableValues.toString())
            }
        }
        this.bleService.readWriteOption(optionName, optionValue)
            .then(response => {
                // localVar = response;
                console.log("our local var is " + JSON.stringify(setting));
                console.log(" response for " + optionName + " = " + response);
                if (response == "ERROR") {
                    alert("Could not change value");
                    setting.value = "";
                } else if (response == "OK") {
                    //OK reply only if we try to set a new value and everything went fine
                    this.bleService.readWriteOption(optionName, "get").then(response => {
                        setting.value = response;
                    });
                } else {
                    setting.value = response;
                }

            });
    }

}
