import { Component, OnInit, NgZone, ViewChild } from '@angular/core';
import { BLE } from '@ionic-native/ble/ngx';
import { BleService } from '../services/ble.service';
import { IonSlides } from '@ionic/angular';

@Component({
    selector: 'app-tab-weight',
    templateUrl: './tab-weight.page.html',
    styleUrls: ['./tab-weight.page.scss'],
})
export class TabWeightPage implements OnInit {
    @ViewChild('slides') slides: IonSlides;


    public devices: any = [];
    public error: any;
    public devicefound: boolean = false;

    public weight: string = "0";

    public isConnected: boolean = false;
    public weightNotifications: boolean = false;

    public scaleInUpgradeMode: boolean = false;

    public ipAddress: string = "";

    private maxWeight: number = 500; //cup fills at 500gr
    private objectHeight: number = 200;

    slideOpts = {
        effect: 'flip'
    };

    constructor(public ble: BLE,
        public zone: NgZone,
        private bleService: BleService) {

        this.connect2BLE();
    }



    ngOnInit() {
    }

    changeMaxWeight() {
        const index = this.slides.getActiveIndex().then((val) => {
            console.log(val);
            switch (val) {
                case 0:
                    this.maxWeight = 75; //espresso
                    this.objectHeight = 122;
                    break;
                case 1:
                    this.maxWeight = 250; //mug
                    this.objectHeight = 142;
                    break;
                case 2:
                    this.maxWeight = 500;
                    this.objectHeight = 152;
                default:
                    this.maxWeight = 500; //whatever, put your load cell max here
                    this.objectHeight = 152;
                    break;
            }
        })
    }

    mapFunction(num: number): number {
        let input_min: number = 0;
        let input_max: number = this.maxWeight;
        let output_min: number = this.objectHeight;
        let output_max: number = 0;
        if (num > this.maxWeight) { num = this.maxWeight; }
        return Math.floor((num - input_min) * (output_max - output_min) / (input_max - input_min) + output_min);
    }


    setOffset() {
        return this.mapFunction(parseFloat(this.weight)) + "px";
    }

    public connect2BLE() {
        // this.bleService.doConnect(this.bleService.scale_uuid, this.onConnection, this.onConnectionError);
        this.bleService.startScan();
        // this.startNotification();
        this.zone.run(() => {
            this.bleService.isConnected.subscribe((value) => {
                this.isConnected = value;
            });

            this.bleService.weight.subscribe((value) => {
                this.weight = value;
            });
            this.bleService.scaleOperationMode.subscribe((value) => {
                console.log("new value !");
                if (value == "1") {
                    this.scaleInUpgradeMode = true;
                    //get IP
                    this.bleService.readWriteOption("wifiIP", "get").then((value) => {
                        this.ipAddress = value;
                    })
                } else {
                    this.scaleInUpgradeMode = false;
                }
            })
        })
    }

    public startNotification() {
        console.log("starting notification subscription");
        this.zone.run(() => {
            this.weightNotifications = true;
        });
    }

    reboot() {
        this.weight = "";
        this.isConnected = false;
        this.scaleInUpgradeMode = false;
        this.rwOption("reboot", "1", null);
    }
    tare() {
        this.rwOption("tare", "1", null);
    }

    public rwOption(optionName: string, optionValue: string, localVar: any) {
        this.bleService.readWriteOption(optionName, optionValue)
            .then(response => {
                localVar = response;
                console.log(" response for " + optionName + " = " + response);
            });
    }





}
