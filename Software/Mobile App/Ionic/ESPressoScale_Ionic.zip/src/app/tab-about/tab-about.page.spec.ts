import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabAboutPage } from './tab-about.page';

describe('TabAboutPage', () => {
  let component: TabAboutPage;
  let fixture: ComponentFixture<TabAboutPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabAboutPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabAboutPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
