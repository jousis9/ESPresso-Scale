import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
    {
        path: 'tabs',
        component: TabsPage,
        children: [
            {
                path: 'tab-weight',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab-weight/tab-weight.module#TabWeightPageModule'
                    }
                ]
            },
            {
                path: 'tab-settings',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab-settings/tab-settings.module#TabSettingsPageModule'
                    }
                ]
            },
            {
                path: 'tab-about',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab-about/tab-about.module#TabAboutPageModule'
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/tabs/tab-weight',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab-weight',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [RouterModule]
})
export class TabsPageRoutingModule { }
